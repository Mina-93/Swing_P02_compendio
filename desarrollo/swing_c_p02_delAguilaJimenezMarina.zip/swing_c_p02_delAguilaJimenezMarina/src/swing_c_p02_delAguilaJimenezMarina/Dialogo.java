/**
 * @author Marina Del Aguila Jimenez 
 * Dialogo.java
 * 17 nov 2021 12:19:08
 */
package swing_c_p02_delAguilaJimenezMarina;

import javax.swing.ImageIcon;
import javax.swing.JDialog;

import java.awt.*;

// TODO: Auto-generated Javadoc
/**
 * The Class Dialogo.
 *
 * @author Marina Del Aguila Jimenez Dialogo.java 17 nov 2021 12:19:08
 */

@SuppressWarnings("serial")
public class Dialogo extends JDialog {

	/** The p 1. */
	private static Panel1 p1;
	
	/** The p 2. */
	public static Panel2 p2;
	
	/** The p 3. */
	public static Panel3 p3;
	
	/** The p 4. */
	public static Panel4 p4;
	
	/** The panel botones. */
	private PanelBotones panelBotones;
	
	/** The layout. */
	private GridBagLayout layout = new GridBagLayout();
	
	/** The constraints. */
	private GridBagConstraints constraints;
	

	/**
	 * Instantiates a new dialogo.
	 */
	public Dialogo() {

		this.setResizable(true);
		this.setTitle("Alta Pisos");
		getContentPane().setBackground(new java.awt.Color(255,250,205));
		this.setLayout(layout);
		constraints = new GridBagConstraints();
		
		// TAMA�O IGUAL A LA RESOLUCION
		this.setSize(Toolkit.getDefaultToolkit().getScreenSize());

		// ICONOS
		this.setIconImage(new ImageIcon(getClass().getResource("../recursos/logo.png")).getImage());

		// PANELES
		p1 = new Panel1();

		p2 = new Panel2();

		p3 = new Panel3();

		p4 = new Panel4();

		panelBotones = new PanelBotones();

		// CONSTRAINTS
		constraints.fill = GridBagConstraints.HORIZONTAL;
		this.addComponent(p1, 0, 0, 3, 1);
		
		constraints.fill = GridBagConstraints.NONE;
		this.addComponent(panelBotones, 1, 0, 3, 1);

		constraints.weightx = 1000; // puede crecer m�s ancho
		constraints.weighty = 1; // puede crecer m�s alto
		constraints.fill = GridBagConstraints.BOTH;
		this.addComponent(p2, 2, 0, 1, 3);
		this.addComponent(p3, 2, 1, 1, 3);
		this.addComponent(p4, 2, 2, 1, 3);
		

		this.setVisible(true);
	}

	/**
	 * Adds the component.
	 *
	 * @param component the component
	 * @param fila the fila
	 * @param columna the columna
	 * @param ancho the ancho
	 * @param alto the alto
	 */
	private void addComponent(Component component, int fila, int columna, int ancho, int alto) {
		constraints.gridx = columna; // set gridx, La columna en la que se
//colocar� el componente.

		constraints.gridy = fila; // set gridy, La fila en la que se colocar�
//el componente.

		constraints.gridwidth = ancho; // set gridwidth, El n�mero de
//columnas que ocupa el componente.

		constraints.gridheight = alto; // set gridheight, El n�mero de
//filas que ocupa el componente.

		layout.setConstraints(component, constraints);
		this.add(component);
	}

}
