/**
 * @author Marina Del Aguila Jimenez 
 * Ventana.java
 * 17 nov 2021 12:18:32
 */
package swing_c_p02_delAguilaJimenezMarina;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.border.Border;

import java.awt.event.KeyEvent;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyListener;

// TODO: Auto-generated Javadoc
/**
 * The Class Ventana.
 *
 * @author Marina Del Aguila Jimenez Ventana.java 17 nov 2021 12:18:32
 */

@SuppressWarnings("serial")
public class Ventana extends JFrame implements ActionListener, KeyListener {
	
	/** The d. */
	Dialogo d;
	
	/** The pantalla. */
	private Toolkit pantalla = Toolkit.getDefaultToolkit();
	
	/** The tamanio. */
	private Dimension tamanio = pantalla.getScreenSize();
	
	/** The barra menu. */
	private JMenuBar barraMenu;
	
	/** The ayuda. */
	private JMenu archivo, registro, ayuda;
	
	/** The acerca de. */
	private JMenuItem salir, altaPisos, bajaPisos, acercaDe;
	
	/** The btn baja. */
	private JButton btnAlta, btnBaja;
	
	/** The imagen baja. */
	private Image imagenAlta, imagenBaja;	

	/** The borde. */
	private Border borde;
	
	/** The titulo. */
	private JLabel titulo;
	

	/**
	 * Instantiates a new ventana.
	 */
	public Ventana() {
		super("Gesti�n de Apartamentos Tur�sticos Marina");
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setLayout(null);
		this.getContentPane().setBackground(new java.awt.Color(70, 86, 125));
		borde = BorderFactory.createLineBorder(new java.awt.Color(70, 86, 125), 2);
		
		// TAMA�O
		this.setSize(tamanio.height / 2, tamanio.width / 4);
		this.setResizable(false);
		this.setLocationRelativeTo(null);
		
		// ICONOS		
		this.setIconImage(new ImageIcon(getClass().getResource("../recursos/logo.png")).getImage());
		
		imagenAlta = new ImageIcon(getClass().getResource("../recursos/alta.png")).getImage();
		ImageIcon imagenBtnAlta = new ImageIcon(imagenAlta.getScaledInstance(50,50,Image.SCALE_SMOOTH));
		
		imagenBaja = new ImageIcon(getClass().getResource("../recursos/baja.png")).getImage();
		ImageIcon imagenBtnBaja = new ImageIcon(imagenBaja.getScaledInstance(50,50,Image.SCALE_SMOOTH));

		// BARRA DE MEN�
		barraMenu = new JMenuBar();
		barraMenu.setSize(520,25);

		// ----------------------------------------

		archivo = new JMenu("Archivo");

		registro = new JMenu("Registro");
		registro.setMnemonic(KeyEvent.VK_R);

		ayuda = new JMenu("Ayuda");

		// ----------------------------------------

		salir = new JMenuItem("Salir");
		salir.addActionListener(this);

		altaPisos = new JMenuItem("Alta Pisos");
		altaPisos.addActionListener(this);

		bajaPisos = new JMenuItem("Baja pisos");
		bajaPisos.addActionListener(this);

		acercaDe = new JMenuItem("Acerca de...");
		acercaDe.addActionListener(this);
		
		//TEXTFIELD
		titulo = new JLabel("Apartamentos tur�sticos Marina");
		titulo.setFont(new Font("STENCIL", 1, 25));
		titulo.setForeground(new java.awt.Color(216, 191, 216));
		titulo.setBounds(30, 40, 500, 50);
	
		
		// BOTONES

		btnAlta = new JButton(imagenBtnAlta);
		btnAlta.setBounds(50, 130, 200, 150);
		btnAlta.setMnemonic(KeyEvent.VK_A);
		btnAlta.addActionListener(this);
		btnAlta.setBackground(new java.awt.Color(216, 191, 216));
		btnAlta.setBorder(borde);
		
		btnBaja = new JButton(imagenBtnBaja);
		btnBaja.setBounds(250, 130, 200, 150);
		btnBaja.setMnemonic(KeyEvent.VK_B);
		btnBaja.addActionListener(this);
		btnBaja.setBackground(new java.awt.Color(216, 191, 216));
		btnBaja.setBorder(borde);
		
		// A�ADIMOS LOS ELEMENTOS
		
		archivo.add(salir);
		
		registro.add(altaPisos);
		registro.add(bajaPisos);
		
		ayuda.add(acercaDe);
		
		barraMenu.add(archivo);
		barraMenu.add(registro);
		barraMenu.add(ayuda);
		
		// ----------------------------------------
		
		add(barraMenu);
		add(titulo);
		add(btnAlta);
		add(btnBaja);
		
		// ----------------------------------------
		
		this.setVisible(true);
		

	}

	/**
	 * Action performed.
	 *
	 * @param e the e
	 */
	@Override
	public void actionPerformed(ActionEvent e) {

		if(e.getSource() == salir)
			System.exit(EXIT_ON_CLOSE);
		
		if(e.getSource() == btnAlta || e.getSource() == altaPisos)
			d = new Dialogo();
		
		if(e.getSource() == btnBaja || e.getSource() == bajaPisos)
			JOptionPane.showMessageDialog(null, "Esta opcion aun no est� desarrollada");
		
		if(e.getSource() == acercaDe)
			JOptionPane.showMessageDialog(null, "Pagina oficial de 'Apartamentos turisticos Marina'");
		
		
	}

	/**
	 * Key typed.
	 *
	 * @param e the e
	 */
	@Override
	public void keyTyped(java.awt.event.KeyEvent e) {
		// TODO Auto-generated method stub

	}

	/**
	 * Key pressed.
	 *
	 * @param e the e
	 */
	@Override
	public void keyPressed(java.awt.event.KeyEvent e) {
		// TODO Auto-generated method stub

	}

	/**
	 * Key released.
	 *
	 * @param e the e
	 */
	@Override
	public void keyReleased(java.awt.event.KeyEvent e) {
		// TODO Auto-generated method stub

	}

}
