/**
 * @autor Marina del Aguila Jimenez
 * 17 nov 2021 ; 17:19:10
 * PanelNinios.java
 */
package swing_c_p02_delAguilaJimenezMarina;

import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;

import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSpinner;
import javax.swing.JTextField;
import javax.swing.SpinnerNumberModel;
import javax.swing.border.Border;

// TODO: Auto-generated Javadoc
/**
 * The Class PanelNinios.
 *
 * @autor Marina del Aguila Jimenez
 * PanelNinios.java
 * 17 nov 2021 ; 17:19:10
 */
@SuppressWarnings("serial")
public class PanelNinios extends JPanel implements FocusListener {

	/** The extra. */
	private JLabel edad, extra;
	
	/** The spinner edad. */
	private JSpinner spinnerEdad;
	
	/** The txt extra. */
	public static JTextField txtExtra;
	
	/** The borde. */
	private Border borde;

	/**
	 * Instantiates a new panel ninios.
	 */
	public PanelNinios() {
		this.setLayout(null);
		this.setBackground(new java.awt.Color(196,163,153));
		borde = BorderFactory.createLineBorder(new java.awt.Color(82, 145, 187), 2);
		this.setBorder(borde);

		
		//LABEL
		edad = new JLabel("Edad:");
		edad.setBounds(25, 20, 50, 25);
		
		extra = new JLabel("Extras:");
		extra.setBounds(25, 75, 50, 25);
		
		// SPINNER
		spinnerEdad = new JSpinner(new SpinnerNumberModel(0, 0, 10, 1));
		spinnerEdad.setBounds(70, 20, 50, 25);
		
		//TEXTFIELD
		txtExtra = new JTextField();
		txtExtra.setEditable(false);
		txtExtra.addFocusListener(this);
		txtExtra.setBounds(70, 75, 150, 25);
		
		//A�ADIMOS LOS ELEMENTOS
		add(edad);
		add(spinnerEdad);
		add(extra);
		add(txtExtra);
		setVisible(false);
	}
	
	
	/**
	 * Gets the edad.
	 *
	 * @return the edad
	 */
	public String getEdad() {
		String edad= spinnerEdad.getValue().toString();
		return edad;
	}

	
	/**
	 * Focus gained.
	 *
	 * @param arg0 the arg 0
	 */
	@Override
	public void focusGained(FocusEvent arg0) {
		int costeEdad=(Integer) spinnerEdad.getValue();
		
		if(costeEdad<=3)
			txtExtra.setText("Cuna");
		
		if(costeEdad>3 && costeEdad<=10)
			txtExtra.setText("Cama supletoria peque�a");
		
		if(costeEdad>10 && costeEdad<=14)
			txtExtra.setText("Cama supletoria normal");

	}

	
	/**
	 * Focus lost.
	 *
	 * @param arg0 the arg 0
	 */
	@Override
	public void focusLost(FocusEvent arg0) {
	}
	
	
	/**
	 * Reset ninios.
	 */
	public void resetNinios() {
		spinnerEdad.setValue(((SpinnerNumberModel) spinnerEdad.getModel()).getMinimum());
		extra.setText("");
	}

}