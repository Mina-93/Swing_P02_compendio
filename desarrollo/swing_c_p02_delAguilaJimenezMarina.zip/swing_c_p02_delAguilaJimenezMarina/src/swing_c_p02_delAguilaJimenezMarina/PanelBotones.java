/**
 * @autor Marina del Aguila Jimenez
 * 27 nov 2021 ; 15:35:13
 * PanelBotones.java
 */
package swing_c_p02_delAguilaJimenezMarina;

import java.awt.BorderLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.Border;


// TODO: Auto-generated Javadoc
/**
 * The Class PanelBotones.
 *
 * @autor Marina del Aguila Jimenez PanelBotones.java 27 nov 2021 ; 15:35:13
 */
@SuppressWarnings("serial")
public class PanelBotones extends JPanel implements ActionListener {
	
	/** The imagen imprimir. */
	private Image imagenNuevo, imagenGuardar, imagenImprimir;
	
	/** The btn imprimir. */
	private JButton btnNuevo, btnGuardar, btnImprimir;
	
	/** The borde. */
	private Border borde;
	
	/** The datos. */
	private static ArrayList<String> datos = new ArrayList<String>();
	//private Panel2 p2;
	
	/**
	 * Instantiates a new panel botones.
	 */
	public PanelBotones() {

		this.setLayout(new BorderLayout());
		this.setBackground(new java.awt.Color(70, 86, 125));

		borde = BorderFactory.createLineBorder(new java.awt.Color(82, 145, 187), 2);
		this.setBorder(borde);

		// ICONOS
		imagenNuevo = new ImageIcon(getClass().getResource("../recursos/nuevo.png")).getImage();
		ImageIcon imagenBtnNuevo = new ImageIcon(imagenNuevo.getScaledInstance(20, 20, Image.SCALE_SMOOTH));

		imagenGuardar = new ImageIcon(getClass().getResource("../recursos/guardar.png")).getImage();
		ImageIcon imagenBtnGuardar = new ImageIcon(imagenGuardar.getScaledInstance(20, 20, Image.SCALE_SMOOTH));

		imagenImprimir = new ImageIcon(getClass().getResource("../recursos/imprimir.png")).getImage();
		ImageIcon imagenBtnImprimir = new ImageIcon(imagenImprimir.getScaledInstance(20, 20, Image.SCALE_SMOOTH));

		// BOTONES
		btnNuevo = new JButton(imagenBtnNuevo);
		btnNuevo.setBounds(10, 10, 50, 50);
		btnNuevo.addActionListener(this);

		btnGuardar = new JButton(imagenBtnGuardar);
		btnGuardar.setBounds(50, 10, 50, 50);
		btnGuardar.addActionListener(this);

		btnImprimir = new JButton(imagenBtnImprimir);
		btnImprimir.setBounds(100, 10, 50, 50);
		btnImprimir.addActionListener(this);

		add(btnNuevo, BorderLayout.EAST);
		add(btnGuardar, BorderLayout.CENTER);
		add(btnImprimir, BorderLayout.WEST);

	}

	/**
	 * Action performed.
	 *
	 * @param e the e
	 */
	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == btnImprimir) {

			datos.clear(); 
			
			String nombre = "", dni = "", telefono = "", apellidos = "", fechaEntrada = "", fechaSalida = "";
			
			String direccion = "", provincia = "", tipoHabitacion = "", cantidadHabitacion = "", edadninios = "", importeTotal = "";
			
			try {
				// PANEL 2
				nombre = Dialogo.p2.getNombre();
				dni = Dialogo.p2.getDni();
				apellidos = Dialogo.p2.getApellidos();
				telefono = Dialogo.p2.getTelefono();
				fechaEntrada = Dialogo.p2.getFechaEntrada();
				fechaSalida = Dialogo.p2.getFechaSalida();
				
				// -------------------------------------------
				// PANEL 3	
				direccion = Dialogo.p3.getDireccion();
				provincia = Dialogo.p3.getProvincia();
				tipoHabitacion = Dialogo.p3.getTipoHabitacion();
				cantidadHabitacion = Dialogo.p3.getNumHabitaciones();
				edadninios = Dialogo.p3.getEdadNinios();
				importeTotal = Dialogo.p3.getImporteTotal();

				// -------------------------------------------

				// A�ADIMOS AL ARRAY
				datos.add(nombre);
				datos.add(apellidos);
				datos.add(dni);
				datos.add(telefono);
				datos.add(fechaEntrada);
				datos.add(fechaSalida);

				datos.add(direccion);
				datos.add(provincia);
				datos.add(tipoHabitacion);
				datos.add(cantidadHabitacion);
				datos.add(edadninios);
				datos.add(importeTotal);

				// RELLENAMOS LAS PESTA�AS
				Panel4.rellenarPanelClientes();
				Panel4.rellenarPanelHabitacion();
				
			} catch (Exception ex) {
				return;
			}
		}

		if (e.getSource() == btnNuevo) {
			Panel2.resetClientes();
			Panel3.resetHabitacion();
			Panel4.resetVentanas();
		}

		if (e.getSource() == btnGuardar) {
			JOptionPane.showMessageDialog(null, "Registro guardado correctamente");
		}

	}

	/**
	 * Gets the datos.
	 *
	 * @return the datos
	 */
	public static ArrayList<String> getDatos() {
		return datos;
	}

}
