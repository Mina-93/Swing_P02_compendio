/**
 * @author Marina Del Aguila Jimenez 
 * panelImagenes.java
 * 17 nov 2021 12:28:28
 */
package swing_c_p02_delAguilaJimenezMarina;

import java.awt.GridLayout;
import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JDialog;
import javax.swing.JLabel;

// TODO: Auto-generated Javadoc
/**
 * The Class PanelImagenes.
 *
 * @author Marina Del Aguila Jimenez
 * panelImagenes.java
 * 17 nov 2021 12:28:28
 */
@SuppressWarnings("serial")
public class PanelImagenes extends JDialog  {

	/** The imag sofa. */
	private JLabel imagSimple, imagDoble, imagSofa;
	
	/** The sofa. */
	private JLabel simple, doble, sofa;
	
	
	/**
	 * Instantiates a new panel imagenes.
	 */
	public PanelImagenes() {
		setSize(640, 480);
		setLocationRelativeTo(null);
		setResizable(false);
		setLayout(new GridLayout(3, 2));
		getContentPane().setBackground(new java.awt.Color(255,250,205));

		
		//Imagenes
		Image imgSimple = new ImageIcon(getClass().getResource("../recursos/hotel1.jpg")).getImage();
		ImageIcon imgSimpleUps = new ImageIcon(imgSimple.getScaledInstance(200, 100, Image.SCALE_SMOOTH));

		Image imgDoble = new ImageIcon(getClass().getResource("../recursos/hotel2.jpg")).getImage();
		ImageIcon imgDobleUps = new ImageIcon(imgDoble.getScaledInstance(200, 100, Image.SCALE_SMOOTH));

		Image imgSuite = new ImageIcon(getClass().getResource("../recursos/hotel3.jpg")).getImage();
		ImageIcon imgSuiteUps = new ImageIcon(imgSuite.getScaledInstance(200, 100, Image.SCALE_SMOOTH));
		
		//------------------------------------------------------------------------------------------------------

		//Incializamos los Jlabel con sus imagenes
		imagSimple = new JLabel(imgSimpleUps);
		imagDoble = new JLabel(imgDobleUps);
		imagSofa = new JLabel(imgSuiteUps);

		//Incializamos los Jlabel con su texto
		simple = new JLabel("Habitacion Simple");
		doble = new JLabel("Habitacion Doble");
		sofa = new JLabel("Habitacion Sofa Cama");

		//A�adimos todo al panel
		add(imagSimple);
		add(simple);
		add(imagDoble);
		add(doble);
		add(imagSofa);
		add(sofa);
		
		//Lo mostramos
		setVisible(true);
	}
}
