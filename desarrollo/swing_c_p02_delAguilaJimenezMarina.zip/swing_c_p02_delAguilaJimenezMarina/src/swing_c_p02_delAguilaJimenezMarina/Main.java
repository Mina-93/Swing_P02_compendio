/**
 * @author Marina Del Aguila Jimenez 
 * Principal.java
 * 17 nov 2021 12:18:06
 */
package swing_c_p02_delAguilaJimenezMarina;


// TODO: Auto-generated Javadoc
/**
 * The Class Main.
 *
 * @author Marina Del Aguila Jimenez
 * Principal.java
 * 17 nov 2021 12:18:06
 */
public class Main {

	/**
	 * The main method.
	 *
	 * @param args the arguments
	 */
	@SuppressWarnings("unused")
	public static void main(String[] args) {
		Ventana v = new Ventana();

	}

}
