/**
 * @author Marina Del Aguila Jimenez 
 * panel2.java
 * 17 nov 2021 12:27:50
 */
package swing_c_p02_delAguilaJimenezMarina;

import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.Border;

import java.awt.Font;
import java.time.LocalDate;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

// TODO: Auto-generated Javadoc
/**
 * The Class Panel2.
 *
 * @author Marina Del Aguila Jimenez
 * panel2.java
 * 17 nov 2021 12:27:50
 */
@SuppressWarnings("serial")
public class Panel2 extends JPanel{

	/** The txt F salida. */
	private static JTextField txtNombre, txtApellidos, txtDni, txtTelefono,txtFEntrada, txtFSalida;
	
	/** The fecha salida. */
	private JLabel nombre, apellidos, dni, telefono, fechaEntrada, fechaSalida;
	
	/** The borde. */
	private Border borde;
	
	/**
	 * Instantiates a new panel 2.
	 */
	public Panel2() {
		this.setLayout(null);
		this.setBackground(new java.awt.Color(196,163,153));
		
		borde = BorderFactory.createLineBorder(new java.awt.Color(82, 145, 187), 2);
		this.setBorder(borde);
		
		// LABEL
		nombre = new JLabel("Nombre:");
		nombre.setFont(new Font("cambria", 1, 16));
		nombre.setBounds(50, 50, 200, 25);
		
		apellidos = new JLabel("Apellidos:");
		apellidos.setFont(new Font("cambria", 1, 16));
		apellidos.setBounds(50, 100, 200, 25);
		
		dni = new JLabel("Dni:");
		dni.setFont(new Font("cambria", 1, 16));
		dni.setBounds(50, 150, 200, 25);
		
		telefono = new JLabel("Telefono:");
		telefono.setFont(new Font("cambria", 1, 16));
		telefono.setBounds(50, 200, 200, 25);
		
		fechaEntrada = new JLabel("Fecha de entrada:");
		fechaEntrada.setFont(new Font("cambria", 1, 16));
		fechaEntrada.setBounds(50, 250, 200, 25);
		
		fechaSalida =  new JLabel("Fecha de salida:");
		fechaSalida.setFont(new Font("cambria", 1, 16));
		fechaSalida.setBounds(50, 300, 200, 25);
		
		
		// TEXTFIELD
		txtNombre = new JTextField();
		txtNombre.setBounds(280, 50, 150, 25);
		txtNombre.requestFocus();
		
		txtApellidos = new JTextField();
		txtApellidos.setBounds(280, 100, 150, 25);
		
		txtDni = new JTextField();
		txtDni.setBounds(280, 150, 150, 25);
		txtDni.setToolTipText("Introduce DNI v�lido (8letras y un n�mero)");
		
		txtTelefono = new JTextField();
		txtTelefono.setBounds(280, 200, 150, 25);
		txtTelefono.setToolTipText("Introduce tel�fono v�lido (9 digitos)");
		
		txtFEntrada = new JTextField(getFechaActual());
		txtFEntrada.setBounds(280, 250, 150, 25);
		
		txtFSalida = new JTextField(getFechaPosterior());
		txtFSalida.setBounds(280, 300, 150, 25);
		
		
		//A�ADIMOS LOS ELEMENTOS
		this.add(nombre);
		this.add(txtNombre);
		this.add(apellidos);
		this.add(txtApellidos);
		this.add(dni);
		this.add(txtDni);
		this.add(telefono);
		this.add(txtTelefono);
		this.add(fechaEntrada);
		this.add(txtFEntrada);
		this.add(fechaSalida);
		this.add(txtFSalida);
		
		
		this.setVisible(true);
		
	}
	
	/**
	 * String to local date.
	 * Convierte una cadena a LocalDate
	 *
	 * @param fecha the fecha
	 * @return the local date
	 */
	private static LocalDate stringToLocalDate(String fecha) {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		LocalDate localDate = LocalDate.parse(fecha, formatter);
		return localDate;
	}
	
	/**
	 * Calcula los dias que hay entre la fecha de salida y la fecha de entrada.
	 *
	 * @return the string
	 */
	static Long calcularDias() {
		LocalDate entrada= stringToLocalDate(txtFEntrada.getText().trim());
		LocalDate salida= stringToLocalDate(txtFSalida.getText().trim());
		
		Long entradaDias=entrada.atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli();
		Long salidaDias=salida.atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli();
		
		if(salidaDias<entradaDias) {
			JOptionPane.showMessageDialog(null, "ERROR EN LA FECHA DE ENTRADA");
			
		}
		
		Long diferencia=salidaDias-entradaDias;
		
		Long millisecondsToDays=TimeUnit.MILLISECONDS.toDays(diferencia);
		
		Long dias=millisecondsToDays;
		
		return dias;
	}

	
	
	/**
	 * Gets the fecha actual.
	 *
	 * @return the fecha actual
	 */
	public static String getFechaActual() {
		LocalDate ahora = LocalDate.now();
		DateTimeFormatter formateador = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		return ahora.format(formateador);
	}

	/**
	 * Gets the fecha posterior.
	 *
	 * @return the fecha posterior
	 */
	public static String getFechaPosterior() {
		LocalDate diaSiguiente = LocalDate.now().plusDays(1);
		DateTimeFormatter formateador = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		return diaSiguiente.format(formateador);
	}

	
	/**
	 * Gets the nombre.
	 *
	 * @return the nombre
	 */
	public String getNombre() {
		return txtNombre.getText().trim();
	}

	
	/**
	 * Gets the dni.
	 *
	 * @return the dni
	 */
	public String getDni() {
		Pattern pattern = Pattern.compile("^[0-9]{8}[A-Z]{1}$");
        Matcher matcher = pattern.matcher(txtDni.getText().trim());
        
		if (!matcher.matches()) 
			JOptionPane.showMessageDialog(null, "ERROR AL INTRODUCIR EL DNI");
		
		return txtDni.getText().trim();
	}

	
	/**
	 * Gets the apellidos.
	 *
	 * @return the apellidos
	 */
	public String getApellidos() {
		return txtApellidos.getText().trim();
	}

	
	/**
	 * Gets the telefono.
	 *
	 * @return the telefono
	 */
	public String getTelefono() {
		Pattern pattern = Pattern.compile("^[0-9]{9}$");
        Matcher matcher = pattern.matcher(txtTelefono.getText().trim());
      
		if (!matcher.matches()) 
			JOptionPane.showMessageDialog(null, "ERROR AL INTRODUCIR EL TELEFONO");
//			
		return txtTelefono.getText().trim();
	}

	
	/**
	 * Gets the fecha entrada.
	 *
	 * @return the fecha entrada
	 */
	public String getFechaEntrada() {
		return txtFEntrada.getText().trim();
	}

	
	/**
	 * Gets the fecha salida.
	 *
	 * @return the fecha salida
	 */
	public String getFechaSalida() {
		return txtFSalida.getText().trim();
	}
	
	
	/**
	 * Reset clientes.
	 */
	public static void resetClientes() {
		txtNombre.setText("");
		txtApellidos.setText("");
		txtDni.setText("");
		txtTelefono.setText("");
		txtFEntrada.setText(getFechaActual());
		txtFSalida.setText(getFechaPosterior());
				
		txtNombre.requestFocus();
	}
	
	
	
}
