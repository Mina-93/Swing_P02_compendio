/**
 * @author Marina Del Aguila Jimenez 
 * panel1.java
 * 17 nov 2021 12:27:44
 */
package swing_c_p02_delAguilaJimenezMarina;

import java.awt.FlowLayout;

import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.Border;

import java.awt.Font;

// TODO: Auto-generated Javadoc
/**
 * The Class Panel1.
 *
 * @author Marina Del Aguila Jimenez panel1.java 17 nov 2021 12:27:44
 */
@SuppressWarnings("serial")
public class Panel1 extends JPanel {

	/** The titulo. */
	private JLabel titulo;
	
	/** The borde. */
	private Border borde;

	/**
	 * Instantiates a new panel 1.
	 */
	public Panel1() {

		this.setBackground(new java.awt.Color(82, 145, 187));
		this.setLayout(new FlowLayout());

		borde = BorderFactory.createLineBorder(new java.awt.Color(255,250,205), 3);
		this.setBorder(borde);

		// TITULO
		titulo = new JLabel("Apartamentos tur�sticos Marina");
		titulo.setFont(new Font("STENCIL", 1, 40));
		titulo.setForeground(new java.awt.Color(255,250,205));

		// A�ADIMOS LOS ELEMENTOS
		add(titulo);

		this.setVisible(true);

	}

}
