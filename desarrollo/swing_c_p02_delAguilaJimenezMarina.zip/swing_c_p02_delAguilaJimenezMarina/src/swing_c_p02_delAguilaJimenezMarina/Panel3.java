/**
 * @author Marina Del Aguila Jimenez 
 * panel3.java
 * 17 nov 2021 12:27:57
 */
package swing_c_p02_delAguilaJimenezMarina;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSpinner;
import javax.swing.JTextField;
import javax.swing.SpinnerNumberModel;
import javax.swing.border.Border;

// TODO: Auto-generated Javadoc
/**
 * The Class Panel3.
 *
 * @author Marina Del Aguila Jimenez panel3.java 17 nov 2021 12:27:57
 */
@SuppressWarnings({ "serial", "unused" })
public class Panel3 extends JPanel implements ActionListener {

	/** The tipo camas. */
	private JLabel direccion, provincia, numHuespedes, numDormitorios, numBa�os, numCamas, tipoCamas;
	
	/** The txt direccion. */
	private static JTextField txtDireccion;
	
	/** The combo provincias. */
	private static JComboBox<String> comboHabitaciones,comboProvincias;;
	
	/** The spinner camas. */
	private static JSpinner spinnerHuesp, spinnerDorm, spinnerBa�os, spinnerCamas;
	
	/** The ninios. */
	private static JCheckBox ninios;
	
	/** The btn imagenes. */
	private JButton btnImagenes;
	
	/** The borde. */
	private Border borde;
	
	/** The panel ninios. */
	private static PanelNinios panelNinios;
	
	/** The total. */
	private static JTextField total;
	
	/** The panel imagenes. */
	private PanelImagenes panelImagenes;

	/**
	 * Instantiates a new panel 3.
	 */
	public Panel3() {

		this.setLayout(null);
		this.setBackground(new java.awt.Color(255, 228, 225));

		borde = BorderFactory.createLineBorder(new java.awt.Color(82, 145, 187), 2);
		this.setBorder(borde);

		// LABEL
		direccion = new JLabel("Direcci�n:");
		direccion.setFont(new Font("cambria", 1, 16));
		direccion.setBounds(50, 50, 200, 25);

		provincia = new JLabel("Provincia:");
		provincia.setFont(new Font("cambria", 1, 16));
		provincia.setBounds(50, 100, 200, 25);

		numHuespedes = new JLabel("Numero de huespedes:");
		numHuespedes.setFont(new Font("cambria", 1, 16));
		numHuespedes.setBounds(50, 150, 200, 25);

		numDormitorios = new JLabel("Numero de dormitorios:");
		numDormitorios.setFont(new Font("cambria", 1, 16));
		numDormitorios.setBounds(50, 200, 200, 25);

		numBa�os = new JLabel("Numero de ba�os:");
		numBa�os.setFont(new Font("cambria", 1, 16));
		numBa�os.setBounds(50, 250, 200, 25);

		numCamas = new JLabel("Numero de camas:");
		numCamas.setFont(new Font("cambria", 1, 16));
		numCamas.setBounds(50, 300, 200, 25);

		tipoCamas = new JLabel("Tipos de camas:");
		tipoCamas.setFont(new Font("cambria", 1, 16));
		tipoCamas.setBounds(50, 350, 200, 25);

		// TEXTFIELD
		txtDireccion = new JTextField();
		txtDireccion.setBounds(280, 50, 300, 25);

		total = new JTextField();
		total.setEditable(false);
		total.setBounds(230, 700, 200, 25);

		// COMBO
		String[] opciones = { "ALMERIA", "GRANADA", "MALAGA", "JAEN", "CORDOBA", "SEVILLA", "CADIZ", "HUELVA" };
		comboProvincias = new JComboBox<String>(opciones);
		comboProvincias.addActionListener(this);
		comboProvincias.setBounds(280, 100, 100, 25);
		comboProvincias.setSelectedItem("ALMERIA");

		String[] tipoHabitacion = { "SIMPLE", "DOBLE", "SOFA CAMA" };
		comboHabitaciones = new JComboBox<String>(tipoHabitacion);
		comboHabitaciones.addActionListener(this);
		comboHabitaciones.setBounds(280, 350, 100, 25);
		comboHabitaciones.setSelectedItem("SIMPLE");

		// SPINNER
		spinnerHuesp = new JSpinner(new SpinnerNumberModel(1, 0, 8, 1));
		spinnerHuesp.setBounds(280, 150, 100, 25);

		spinnerDorm = new JSpinner(new SpinnerNumberModel(1, 0, 4, 1));
		spinnerDorm.setBounds(280, 200, 100, 25);

		spinnerBa�os = new JSpinner(new SpinnerNumberModel(1, 0, 2, 1));
		spinnerBa�os.setBounds(280, 250, 100, 25);

		spinnerCamas = new JSpinner(new SpinnerNumberModel(1, 0, 4, 1));
		spinnerCamas.setBounds(280, 300, 100, 25);

		// CHECKBOX
		ninios = new JCheckBox("�Ni�os?");
		ninios.addActionListener(this);
		ninios.setBounds(280, 450, 100, 25);

		panelNinios = new PanelNinios();
		panelNinios.setBounds(210, 500, 250, 150);

		// BOTON
		btnImagenes = new JButton("Imagenes de las habitaciones");
		btnImagenes.setBounds(130, 800, 375, 50);
		btnImagenes.addActionListener(this);

		// A�ADIMOS LOS ELEMENTOS
		add(direccion);
		add(txtDireccion);
		add(total);
		add(provincia);
		add(numHuespedes);
		add(numDormitorios);
		add(numBa�os);
		add(numCamas);
		add(tipoCamas);
		add(comboProvincias);
		add(comboHabitaciones);
		add(spinnerHuesp);
		add(spinnerDorm);
		add(spinnerBa�os);
		add(spinnerCamas);
		add(panelNinios);
		add(btnImagenes);
		add(ninios);

	}

	/**
	 * Calcular importe.
	 */
	public static void calcularImporte() {
		final int SIMPLE = 15, DOBLE = 20, SOFA = 15;
		long numDia = Panel2.calcularDias();
		int camaNinios = 0;
		int numBanios = (Integer) spinnerBa�os.getValue();
		int banio = 25 * numBanios;

		if (ninios.isSelected())
			camaNinios = 12;

		if (comboHabitaciones.getSelectedIndex() == 0) {
			int resultado = (int) ((SIMPLE + camaNinios + banio) * numDia);
			setTotal(resultado);
		}

		if (comboHabitaciones.getSelectedIndex() == 1) {
			int resultado = (int) ((DOBLE + camaNinios + banio) * numDia);
			setTotal(resultado);
		}

		if (comboHabitaciones.getSelectedIndex() == 2) {
			int resultado = (int) ((SOFA + camaNinios + banio) * numDia);
			setTotal(resultado);
		}

	}

	/**
	 * Action performed.
	 *
	 * @param e the e
	 */
	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == ninios) {
			if (ninios.isSelected())
				panelNinios.setVisible(true);

			else
				panelNinios.setVisible(false);
		}

		if (e.getSource() == btnImagenes) {
			panelImagenes = new PanelImagenes();
		}
	}

	/**
	 * Gets the direccion.
	 *
	 * @return the direccion
	 */
	public String getDireccion() {
		return txtDireccion.getText().trim();
	}

	/**
	 * Gets the provincia.
	 *
	 * @return the provincia
	 */
	public String getProvincia() {
		return comboProvincias.getSelectedItem().toString();
	}

	/**
	 * Gets the tipo habitacion.
	 *
	 * @return the tipo habitacion
	 */
	public String getTipoHabitacion() {
		return comboHabitaciones.getSelectedItem().toString();
	}

	/**
	 * Gets the num habitaciones.
	 *
	 * @return the num habitaciones
	 */
	public String getNumHabitaciones() {
		return spinnerDorm.getValue().toString();
	}

	/**
	 * Gets the edad ninios.
	 *
	 * @return the edad ninios
	 */
	public String getEdadNinios() {
		if (ninios.isSelected() == true) 
			return panelNinios.getEdad();
		
		return "N";
	}

	/**
	 * Sets the total.
	 *
	 * @param importe the new total
	 */
	public static void setTotal(int importe) {
		total.setText(Integer.toString(importe) + " �");
	}

	/**
	 * Gets the importe total.
	 *
	 * @return the importe total
	 */
	public String getImporteTotal() {
		calcularImporte();
		return total.getText();
	}

	/**
	 * Reset habitacion.
	 */
	public static void resetHabitacion() {
		comboProvincias.setSelectedIndex(0);
		txtDireccion.setText("");
		comboHabitaciones.setSelectedIndex(0);
		spinnerDorm.setValue(((SpinnerNumberModel) spinnerDorm.getModel()).getMinimum());
		panelNinios.resetNinios();
		total.setText("");
	}

}
