/**
 * @author Marina Del Aguila Jimenez 
 * panel4.java
 * 17 nov 2021 12:28:19
 */
package swing_c_p02_delAguilaJimenezMarina;

import java.awt.BorderLayout;
import java.awt.Font;
import java.util.ArrayList;

import javax.swing.BorderFactory;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
import javax.swing.border.Border;

// TODO: Auto-generated Javadoc
/**
 * The Class Panel4.
 *
 * @author Marina Del Aguila Jimenez panel4.java 17 nov 2021 12:28:19
 */
@SuppressWarnings("serial")
public class Panel4 extends JPanel {

	/** The borde. */
	private Border borde;
	
	/** The pestanias. */
	private JTabbedPane pestanias;
	
	/** The datos. */
	private static ArrayList<String> datos = PanelBotones.getDatos();
	
	/** The pest clientes. */
	private static JTextArea pestClientes;
	
	/** The pest habitacion. */
	private static JTextArea pestHabitacion;

	/**
	 * Instantiates a new panel 4.
	 */
	public Panel4() {
		this.setLayout(null);
		this.setBackground(new java.awt.Color(216, 191, 216));

		borde = BorderFactory.createLineBorder(new java.awt.Color(82, 145, 187), 2);
		this.setBorder(borde);

		pestanias = new JTabbedPane();

		// PESTA�A 1
		JPanel pest1 = new JPanel();
		pest1.setLayout(new BorderLayout());
		pest1.setBackground(new java.awt.Color(196,163,153));
		
		pestClientes = new JTextArea("");
		pestClientes.setEditable(false);

		pest1.add(pestClientes);

		// PESTA�A 2
		JPanel pest2 = new JPanel();
		pest2.setLayout(new BorderLayout());
		pest2.setBackground(new java.awt.Color(255, 228, 225));

		pestHabitacion = new JTextArea("");
		pestHabitacion.setEditable(false);

		pest2.add(pestHabitacion);

		// A�ADIMOS LOS COMPONENTES A LAS PESTA�AS
		pestanias.addTab("Datos Cliente", pest1);
		pestanias.addTab("Datos Habitacion", pest2);

		pestanias.setBounds(75, 100, 450, 500);
		pestanias.setBackgroundAt(0, new java.awt.Color(196,163,153));
		pestanias.setBackgroundAt(1, new java.awt.Color(255, 228, 225));

		// A�ADIMOS LOS COMPONENTES AL PANEL
		add(pestanias);

		this.setVisible(true);
	}

	/**
	 * Rellenar panel clientes.
	 */
	public static void rellenarPanelClientes() {

		pestClientes.setText("Nombre: " + datos.get(0) + "\n\n" 
				+ "Apellidos: " + datos.get(1) + "\n\n" 
				+ "DNI: " + datos.get(2) + "\n\n" 
				+ "Telefono: " + datos.get(3) + "\n\n" 
				+ "Fecha de entrada: " + datos.get(4) + "\n\n"
				+ "Fecha de salida: " + datos.get(5));
		pestClientes.setFont(new Font("cambria", 1, 16));
	}

	/**
	 * Rellenar panel habitacion.
	 */
	public static void rellenarPanelHabitacion() {
		String ninios = "No hay ni�os";

		if (datos.get(10).trim() != "N") {
			ninios = datos.get(10);
		}

		pestHabitacion.setText("Direccion: "+ datos.get(6)+"\n\n"
				+ "Provincia: " + datos.get(7) + "\n\n"
				+ "Tipo de habitacion: " + datos.get(8) + "\n\n" 
				+ "Cantidad de habitaciones: "+ datos.get(9) + "\n\n" 
				+ "Edad de los ni�os: " + ninios + "\n\n" 
				+ "Importe total: " + datos.get(11));
		pestHabitacion.setFont(new Font("cambria", 1, 16));

	}

	/**
	 * Reset ventanas.
	 */
	public static void resetVentanas() {

		if (!pestClientes.getText().isEmpty()) {
			pestClientes.setText("");
			pestHabitacion.setText("");
		} else {
			JOptionPane.showMessageDialog(null, "YA EST� VACIO");
		}
	}

}
